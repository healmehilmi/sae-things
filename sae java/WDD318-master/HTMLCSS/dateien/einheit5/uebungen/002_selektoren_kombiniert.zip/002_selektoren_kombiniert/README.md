002_selektoren_kombiniert
========
Kombinierte und erweiterte Selektion

### Angabe:

* Alle `div` mit der Klasse `.highlight` bekommen einen roten 5px Rahmen
* Alle `strong` grüne Schriftfarbe 
* Alle `strong`, die Kindelemente von `.highlight` sind, blaue Schriftfarbe 
* Alle `.highlight` Elemente mit der Klasse `.indent` einen Außenabstand links (`margin-left`) von 40px
